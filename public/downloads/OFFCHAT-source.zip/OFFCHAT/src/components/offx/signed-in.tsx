import { useEffect, useState, type ReactNode } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Skeleton } from "@/components/ui/skeleton";
import { bootstrapMe } from "@/lib/offx/server";
import { cacheGet, cacheSet } from "@/lib/offx/offline";
import type { Profile } from "@/lib/offx/types";
import { VerifyEmail } from "./verify-email";
import { LanProvider } from "./lan-provider";

export function VerifyGate({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Profile | null>(null);
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const profile = await bootstrapMe();
        await cacheSet("me", profile);
        if (alive) setMe(profile);
      } catch {
        const cached = await cacheGet<Profile>("me");
        if (alive) {
          if (cached) setMe(cached);
          else setBlocked(true);
        }
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  if (blocked && !me) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg px-6 text-center text-sm text-muted">
        Einmal mit Internet anmelden — danach läuft Offchat im lokalen Netz weiter.
      </div>
    );
  }
  if (!me) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg">
        <Skeleton className="h-10 w-40 rounded-lg" />
      </div>
    );
  }
  if (!me.emailVerified) {
    return <VerifyEmail onVerified={(next) => setMe(next)} />;
  }
  return <LanProvider me={me}>{children}</LanProvider>;
}

export function RequireSignIn({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg">
        <Skeleton className="h-10 w-40 rounded-lg" />
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return <VerifyGate>{children}</VerifyGate>;
}
