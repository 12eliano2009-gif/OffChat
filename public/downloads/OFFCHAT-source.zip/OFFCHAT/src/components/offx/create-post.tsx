import { ImagePlus, Loader2 } from "lucide-react";
import { useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { fileToMedia } from "@/lib/offx/media";
import { useT } from "@/lib/offx/settings";
import { useLan } from "./lan-provider";
import { EmojiPicker } from "./emoji-picker";

export function CreatePost() {
  const lan = useLan();
  const t = useT();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [caption, setCaption] = useState("");
  const [preview, setPreview] = useState<{
    mediaType: "image" | "video";
    mediaUrl: string;
    posterUrl: string | null;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const [picking, setPicking] = useState(false);

  async function onFile(file: File | undefined) {
    if (!file) return;
    setPicking(true);
    try {
      const media = await fileToMedia(file);
      setPreview(media);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Datei ungültig.");
    } finally {
      setPicking(false);
    }
  }

  function publish() {
    if (!preview) return;
    setBusy(true);
    try {
      lan.publishPost({ caption, ...preview });
      toast.success(t("create.posted"));
      void navigate({ to: "/" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Post fehlgeschlagen.");
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto w-full max-w-lg px-4 py-6 tab-safe">
      <h1 className="mb-2 font-display text-2xl tracking-[0.12em]">{t("create.title")}</h1>
      <p className="mb-5 text-sm text-muted">
        {t("create.hint", { net: lan.net?.label ?? t("lan.local") })}
      </p>
      <input
        ref={inputRef}
        type="file"
        accept="image/*,video/*"
        className="sr-only"
        onChange={(e) => void onFile(e.target.files?.[0])}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="mb-4 flex aspect-[4/5] w-full items-center justify-center overflow-hidden rounded-xl bg-elevated shadow-[var(--shadow-border)]"
      >
        {preview?.mediaType === "video" ? (
          <video
            src={preview.mediaUrl}
            poster={preview.posterUrl ?? undefined}
            className="size-full object-cover"
            muted
            playsInline
            controls
          />
        ) : preview ? (
          <img src={preview.mediaUrl} alt="" className="size-full object-cover" />
        ) : (
          <span className="flex flex-col items-center gap-2 text-muted">
            {picking ? <Loader2 className="size-7 animate-spin" /> : <ImagePlus className="size-7" />}
            <span className="text-sm">{t("create.pick")}</span>
            <span className="text-xs text-faint">Videos bis 2,4 MB</span>
          </span>
        )}
      </button>
      <div className="relative">
        <Textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder={t("create.caption")}
          maxLength={500}
          className="min-h-24 pr-12"
        />
        <div className="absolute bottom-1 right-1">
          <EmojiPicker onPick={(e) => setCaption((prev) => prev + e)} />
        </div>
      </div>
      <Button className="mt-4 h-12 w-full rounded-lg" disabled={!preview || busy} onClick={publish}>
        {busy ? "…" : t("create.share")}
      </Button>
    </div>
  );
}
