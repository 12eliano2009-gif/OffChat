# OFFCHAT — Quellcode

Offline Social Network (PWA). Feed, Chat und Posts laufen im lokalen WLAN.
Internet nur für Login, NOX-Kauf und Netz-Suche.

## Start

```bash
npm install
npm run dev
```

Die App startet auf Port 8080. PWA-Install über den Browser (Home-Bildschirm).

## Stack

- React 19 + TanStack Start/Router/Query
- Tailwind v4
- Better Auth (Google + E-Mail/Passwort)
- PGLite (lokale SQL-Datenbank) + Kysely
- WebRTC P2P + LAN-Event-Bus für Feed/Chat/Likes
- PWA (manifest + service worker)

## Ordner

```
src/
  components/offx/   UI: Feed, Chat, Wallet, Profil, Login, Install
  components/ui/     kleine Basis-Komponenten (Button, Input, …)
  lib/offx/          LAN, NOX-Zahlungen, Packs, Offline, i18n
  lib/auth/          Anmeldung
  lib/multiplayer/   WebRTC P2P
  routes/            Seiten und API (/api/lan, /api/rtc, /api/auth)
migrations/          SQL-Schema (Auth, Profile, NOX, Treasury)
public/              Icons, OG-Karte, Manifest, Service Worker
native/              Android-WebView + Windows-Wrapper (Quellcode)
```

## Wichtige Dateien

| Datei | Inhalt |
|---|---|
| `src/components/offx/lan-provider.tsx` | LAN-State: Posts, Likes, Chat, Delete-Fanout |
| `src/lib/offx/server.ts` | Serverfunktionen: Profil, NOX, Packs |
| `src/lib/offx/pay.ts` | 70/30-Split, Wallet |
| `src/lib/offx/packs.ts` | NOX-Pakete (10 NOX = 0,99 €) |
| `src/lib/multiplayer/p2p.ts` | WebRTC Mesh |
| `src/routes/api/lan.ts` | LAN-Event-Bus |
| `src/routes/api/rtc.ts` | Signaling |
| `src/components/offx/feed.tsx` | Feed + Post löschen |
| `src/components/offx/wallet-view.tsx` | Wallet + Kartenkauf |
| `public/og.jpg` | Link-Vorschau 1200×630 |
| `public/manifest.webmanifest` | PWA-Manifest |

## Währung

- Startguthaben: 25 NOX
- 10 NOX = 0,99 €, Mengenrabatt bei größeren Packs
- Senden: 70 % Empfänger, 30 % Offchat-Treasury
- Kein Auszahlen

Nicht enthalten: `node_modules`, Build-Ordner, Android-Keystore.
