import { Link } from "@tanstack/react-router";
import { Monitor, Smartphone } from "lucide-react";
import { formatEuro } from "@/lib/offx/packs";
import { AuthForm } from "./auth-form";
import { InstallButton } from "./install";

export function Landing() {
  return (
    <main className="relative min-h-dvh bg-bg text-fg">
      <img
        src="/brand/offx-hero.jpg"
        alt=""
        className="absolute inset-0 size-full object-cover object-top"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/75 to-bg/25" />
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-md flex-col px-5 pb-8 pt-16">
        <div className="space-y-2 pr-20">
          <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-muted">
            Lokales soziales Netz
          </p>
          <h1 className="font-display text-4xl tracking-[0.1em] text-fg lg:text-5xl lg:tracking-[0.12em]">
            OFFCHAT
          </h1>
          <p className="max-w-sm text-pretty text-sm leading-relaxed text-muted">
            Social Media fürs WLAN vor Ort — öffentlich oder privat. Feed, Chat
            und Posts bleiben zwischen den Geräten hier. Ein Tab geht ins
            Internet: NOX holen.
          </p>
        </div>

        <div className="mt-auto space-y-3 pt-6">
          <div className="grid grid-cols-3 gap-2">
            <PlatformChip icon={Smartphone} label="Android" />
            <PlatformChip icon={Smartphone} label="iPhone" />
            <PlatformChip icon={Monitor} label="PC & Mac" />
          </div>
          <div className="space-y-3 rounded-2xl bg-surface/90 p-5 shadow-[var(--shadow-border)] backdrop-blur-md">
            <InstallButton />
            <Link
              to="/get"
              className="block text-center text-sm text-muted underline-offset-4 hover:underline"
            >
              So kommt Offchat aufs Gerät
            </Link>
            <p className="text-center text-[11px] uppercase tracking-[0.18em] text-faint">
              Anmelden
            </p>
            <AuthForm compact />
            <p className="text-center text-xs text-faint">
              10 NOX = {formatEuro(0.99)} · 70 % kommen an
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}

function PlatformChip({ icon: Icon, label }: { icon: typeof Smartphone; label: string }) {
  return (
    <div className="flex flex-col items-center gap-1 rounded-xl bg-surface/80 px-2 py-3 backdrop-blur">
      <Icon className="size-4 text-fg" />
      <span className="text-[11px] text-muted">{label}</span>
    </div>
  );
}
