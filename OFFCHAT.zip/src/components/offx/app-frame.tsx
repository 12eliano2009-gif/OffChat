import { Link, useRouterState } from "@tanstack/react-router";
import {
  Globe,
  House,
  MessageCircle,
  PlusSquare,
  UserRound,
  Wifi,
} from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { OffxLockup, OffxMark } from "./logo";
import { InstallButton } from "./install";
import { useLan } from "./lan-provider";

const NAV = [
  { to: "/", label: "Für dich", icon: House, exact: true },
  { to: "/messages", label: "Chats", icon: MessageCircle, exact: false },
  { to: "/create", label: "Neu", icon: PlusSquare, exact: true },
  { to: "/online", label: "Online", icon: Globe, exact: true },
  { to: "/profile", label: "Profil", icon: UserRound, exact: true },
] as const;

function isActive(pathname: string, to: string, exact: boolean) {
  if (exact) return pathname === to;
  if (to === "/messages") return pathname === "/messages" || pathname.startsWith("/c/");
  return pathname === to || pathname.startsWith(`${to}/`);
}

function LanChip() {
  const lan = useLan();
  const here = lan.people.length;
  return (
    <span className="inline-flex max-w-[70vw] items-center gap-1.5 rounded-full bg-elevated px-2.5 py-1 text-[11px] text-muted">
      <Wifi className="size-3.5 shrink-0 text-fg" />
      <span className="truncate">{lan.net?.label ?? "Lokales Netz"}</span>
      <span className="text-faint">·</span>
      <span className="shrink-0 tabular-nums">{here === 0 ? "nur du" : `${here} hier`}</span>
    </span>
  );
}

export function AppFrame({
  children,
  hideChrome = false,
}: {
  children: ReactNode;
  hideChrome?: boolean;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-border bg-bg px-4 py-6 lg:flex">
        <Link to="/" className="mb-2 px-2">
          <OffxLockup />
        </Link>
        <p className="mb-6 px-2">
          <LanChip />
        </p>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const active = isActive(pathname, item.to, item.exact);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-12 items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors duration-150",
                  active ? "bg-elevated text-fg" : "text-muted hover:bg-elevated hover:text-fg",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="px-0 pt-4">
          <InstallButton compact />
        </div>
      </aside>

      {!hideChrome && (
        <header className="sticky top-0 z-20 border-b border-border bg-bg/90 backdrop-blur lg:hidden">
          <div className="flex h-12 items-center justify-between gap-3 px-4">
            <Link to="/" className="flex items-center gap-2">
              <OffxMark className="h-5 w-6" />
              <span className="font-display text-base tracking-[0.12em]">OFFCHAT</span>
            </Link>
            <LanChip />
          </div>
        </header>
      )}

      <div className="lg:pl-60">{children}</div>

      {!hideChrome && (
        <nav
          className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur lg:hidden"
          style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        >
          <div className="mx-auto grid max-w-lg grid-cols-5">
            {NAV.map((item) => {
              const active = isActive(pathname, item.to, item.exact);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-14 flex-col items-center justify-center gap-0.5 text-[10px] font-medium",
                    active ? "text-fg" : "text-muted",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.25 : 1.75} />
                  {item.label}
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
