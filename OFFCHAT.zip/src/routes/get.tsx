import { createFileRoute, Link } from "@tanstack/react-router";
import { Monitor, Smartphone } from "lucide-react";
import { InstallButton } from "@/components/offx/install";
import { OffxLockup } from "@/components/offx/logo";

export const Route = createFileRoute("/get")({ component: GetApp });

function GetApp() {
  return (
    <main className="min-h-dvh bg-bg px-5 py-12 text-fg">
      <div className="mx-auto w-full max-w-md space-y-8">
        <OffxLockup />
        <div>
          <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-muted">
            Von der Website aufs Gerät
          </p>
          <h1 className="mt-2 font-display text-4xl tracking-[0.12em]">OFFCHAT HOLEN</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            Kein Store. Einmal von dieser Seite aufs Gerät — dann ist Offchat das
            soziale Netz in jedem WLAN, öffentlich oder privat. Feed, Chat und
            Posts bleiben zwischen den Geräten. Internet nur für NOX.
          </p>
        </div>

        <InstallButton />

        <ul className="space-y-4">
          <Step
            icon={Smartphone}
            title="Android"
            body="Chrome öffnen → diese Seite → Menü ⋮ → „App installieren“ oder „Zum Startbildschirm“."
          />
          <Step
            icon={Smartphone}
            title="iPhone & iPad"
            body="In Safari (nicht Chrome) → Teilen → „Zum Home-Bildschirm“. Dann wie eine App."
          />
          <Step
            icon={Monitor}
            title="Windows, Mac, Linux"
            body="Chrome oder Edge: Install-Symbol in der Adressleiste, oder Menü → „App installieren“."
          />
        </ul>

        <div className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-sm font-medium">Das WLAN ist die App</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Für dich, Chats, Neu, Profil — alles lokal. Der Tab „Online“ ist der
            einzige Weg ins Internet: NOX kaufen, Netz finden.
          </p>
        </div>

        <Link to="/login" className="block text-center text-sm text-muted underline-offset-4 hover:underline">
          Schon installiert? Anmelden
        </Link>
      </div>
    </main>
  );
}

function Step({
  icon: Icon,
  title,
  body,
}: {
  icon: typeof Smartphone;
  title: string;
  body: string;
}) {
  return (
    <li className="flex gap-3">
      <span className="grid size-10 shrink-0 place-items-center rounded-lg bg-elevated text-fg">
        <Icon className="size-4" />
      </span>
      <span>
        <span className="block text-sm font-medium">{title}</span>
        <span className="text-sm leading-relaxed text-muted">{body}</span>
      </span>
    </li>
  );
}
